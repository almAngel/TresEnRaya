package alm.android.tresenraya;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.ViewGroup;
import android.widget.GridView;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.casillas)
    public GridView casillas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        DisplayMetrics metrics = this.getResources().getDisplayMetrics();
        float ratio = ((float) metrics.heightPixels / (float) metrics.widthPixels);


        ViewGroup.LayoutParams layoutParams = casillas.getLayoutParams();

        System.out.println("Ratio: " + ratio);
        layoutParams.height = (int) ((float) metrics.widthPixels / 1.33f);

        casillas.setLayoutParams(layoutParams);

    }

}
